import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import javax.swing.table.*;
/**
 * This is a student table model
 * @author pengzhizhong
 *
 */
public class StuModel extends AbstractTableModel {
	Vector rowData, columnNames;
	//定义数据库
	Connection ct= null;
	PreparedStatement ps= null;	
	ResultSet rs = null;
	public static void main(String[] args) {
		
	}
	public void init(String sql) {
		if(sql.equals("")){
			sql="select * from student.student_info.stu";
		}
		columnNames = new Vector();
		//设置列名
		columnNames.add("StuId");
		columnNames.add("StuName");
		columnNames.add("StuSex");
		columnNames.add("StuAge");
		columnNames.add("StuHometown");
		columnNames.add("StuDepName");
		
		rowData = new Vector();
		try {
			//加载驱动
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			ct=DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=student;user=sa;password=Frothfoam,.365");
			ps=ct.prepareStatement(sql);
			rs=ps.executeQuery();
			
			while(rs.next()) {
				//rowData可以存放多行
				Vector hang = new Vector();
				hang.add(rs.getString(1));
				hang.add(rs.getString(2));
				hang.add(rs.getString(3));
				hang.add(rs.getString(4));
				hang.add(rs.getString(5));
				hang.add(rs.getString(6));
				
				rowData.add(hang);
			}
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
				if(ct!=null) ct.close();
				
			} catch (Exception e) {
				e.printStackTrace();
			} 
		}
	}
	public void AddStu(String sql) {
		
	}
	public StuModel(String sql) {
		this.init(sql);
	}
	
    public StuModel() {
		this.init("");
	}
    
   
	@Override
	public String getColumnName(int column) {
		// TODO Auto-generated method stub
		return (String)this.columnNames.get(column);
	}

	@Override
	public int getRowCount() {		
		// TODO Auto-generated method stub
		return this.rowData.size();
	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return this.columnNames.size();
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		return ((Vector)this.rowData.get(rowIndex)).get(columnIndex);
	}

}
