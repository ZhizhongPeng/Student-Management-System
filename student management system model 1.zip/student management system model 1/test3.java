import javax.swing.*;
import java.util.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
public class test3 extends JFrame implements ActionListener{
	JPanel jp1,jp2;
	JLabel jl1;
	JButton jb1,jb2,jb3,jb4;
	JTable jt;
	JScrollPane jsp;
	JTextField jtf;
	StuModel sm;
	//define database variable
		Connection ct= null;
		PreparedStatement ps= null;	
		ResultSet rs = null;
	
    public static void main(String args[]) {
    	test3 tst3 = new test3();
    }
    
    public test3() {
    	jp1 = new JPanel();
    	jtf = new JTextField(10);
    	jb1 = new JButton("Search");
    	jb1.addActionListener(this);
    	jl1 = new JLabel("Please enter student name");
    	
    	jp1.add(jl1);
    	jp1.add(jtf);
    	jp1.add(jb1);
    	
    	jp2 = new JPanel();
    	jb2 = new JButton("Add");
    	jb2.addActionListener(this);
    	jb3 = new JButton("Update");
    	jb3.addActionListener(this);
    	jb4 = new JButton("Delete");
    	jb4.addActionListener(this);
    	
    	jp2.add(jb2);
    	jp2.add(jb3);
    	jp2.add(jb4);
    	
		sm = new StuModel();

		
		jt= new JTable(sm);
		
		jsp=new JScrollPane(jt);
		
		this.add(jsp);
		this.add(jp1,"North");
		this.add(jp2,"South");
		
		this.setSize(400,300);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
    }

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==jb1) {
			System.out.println("hhh");
			String name = this.jtf.getText().trim();
			
			String sql = "select * from student.student_info.stu where StuName='"+name+"'";
			
			sm = new StuModel(sql);
			
			jt.setModel(sm);
		} else if(e.getSource()==jb2) {
			StuAddDialog sa = new StuAddDialog(this,"Add student", true);
			//create a new model, refresh
			sm = new StuModel();
			jt.setModel(sm);
		} else if(e.getSource()==jb3) {
			int rowNum = this.jt.getSelectedRow();
			if(rowNum==-1) {
				JOptionPane.showMessageDialog(this, "Please select one line");
				return;
			}
			//get stuId
			String StuId = (String)sm.getValueAt(rowNum, 0);
			StuUpdDialog su = new StuUpdDialog(this,"Update student", true, sm, rowNum);
			
			sm = new StuModel();
			jt.setModel(sm);
		} else if(e.getSource()==jb4) {
			int rowNum = this.jt.getSelectedRow();
			if(rowNum==-1) {
				JOptionPane.showMessageDialog(this, "Please select one line");
				return;
			}
			//get stuId
			String StuId = (String)sm.getValueAt(rowNum, 0);
			
			try {
				//load driver
				Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
				ct=DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=student;user=sa;password=Pzz,.123456");
				ps=ct.prepareStatement("delete from student.student_info.stu where StuId=?");
				ps.setString(1, StuId);
				ps.executeUpdate();
			} catch(Exception e1) {
				e1.printStackTrace();
			} finally {
				try {
					if(rs!=null) rs.close();
					if(ps!=null) ps.close();
					if(ct!=null) ct.close();
					
				} catch (Exception e2) {
					e2.printStackTrace();
				} 
			}	
			sm = new StuModel();
			jt.setModel(sm);
		}
	}
}
